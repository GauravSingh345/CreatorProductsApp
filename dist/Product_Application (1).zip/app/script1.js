
var data = [


  {
    "name": "Pleated & Honeycomb Blinds",
    "make": "Pleated & Honeycomb Blinds",
    "model": "",
    "type": "",
    "variety": "",
    "gallery": [
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs02691d8e03f94fe59f7b5d5dec34b784" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs5c11597282e1439cb829d940b20998eb" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs2343c40adf3344d1b8fbfe40a03e0e86" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs3abc7e84c3c64ad980f604751fe81225" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs62b4351434b14a5daa86d99039ad9708" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs91c3e261642744e890520a8a1b824455" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs9bccc5711dcc4d0b809132b941077756" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsc5f98c1926ca4650ae6780d3dba8eba9" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs5ee958a56b62481dacf945d821df016c" },
      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evsc56caa17d7e64395a64914ea625f1471?toolbar=false&appearance=light&themecolor=green" },
      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evs64b39bd59b684543b97bcaf28207f8a8?toolbar=false&appearance=light&themecolor=green" },
      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evs1c7e9e970a1948f4931741ee777d5a7e?toolbar=false&appearance=light&themecolor=green" },
      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evs9efa670a89e140ff9ca521a6fe1dcdb6?toolbar=false&appearance=light&themecolor=green" },
      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evscdd6aa537bed4bd69142ac1803d6fb5d?toolbar=false&appearance=light&themecolor=green" },
    ]
  },

  {
    "name": "Velux Blinds",
    "make": "Velux Blinds",
    "model": "",
    "type": "",
    "variety": "",
    "gallery": [
      { "type": "image", "src": "https://scontent.fixc1-7.fna.fbcdn.net/v/t39.30808-6/450559188_18025864142332225_1606514513497712624_n.jpg?stp=cp6_dst-jpegr_s600x600&_nc_cat=103&ccb=1-7&_nc_sid=127cfc&_nc_ohc=vh4F02YojXAQ7kNvgEb0CCk&_nc_zt=23&se=-1&_nc_ht=scontent.fixc1-7.fna&_nc_gid=A0r-FAn6ltOD1Jhe14q_9hs&oh=00_AYApr3KF1sdOurTz_fkXIC0o7UBOIBFLwPp1SVJXd4iXqQ&oe=671662C3" },
      { "type": "image", "src": "https://scontent.fixc4-1.fna.fbcdn.net/v/t39.30808-6/450261023_18025864151332225_1150527421346606920_n.jpg?stp=cp6_dst-jpegr&_nc_cat=108&ccb=1-7&_nc_sid=127cfc&_nc_ohc=lJsaOpb3ZOkQ7kNvgHeZ8AY&_nc_zt=23&se=-1&_nc_ht=scontent.fixc4-1.fna&_nc_gid=AXJVjZmrEQc9i3We4V2j4f1&oh=00_AYDw7HFJZMV20VkbRAjjrTS2Jz_W-JURDT4BOqu0_iCdwg&oe=6723CACD" }, // Video thumbnail
      { "type": "image", "src": "https://scontent.fixc4-2.fna.fbcdn.net/v/t39.30808-6/450256619_18025864160332225_9180367606726233063_n.jpg?stp=cp6_dst-jpegr&_nc_cat=101&ccb=1-7&_nc_sid=127cfc&_nc_ohc=bP2qyw9a-fcQ7kNvgGOjYBX&_nc_zt=23&se=-1&_nc_ht=scontent.fixc4-2.fna&_nc_gid=ARpioWu4UqSnnRfvVG3eeWm&oh=00_AYD8DYqZ0jkcDyF6PtDzj3StAAK3qGAM3qvzygT1R0TiJA&oe=6723E87B" },

    ]
  },
  {
    "name": "Venetian blinds",
    "make": "Venetian blinds",
    "model": "",
    "type": "",
    "variety": " ",
    "gallery": [
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs1d6ff11529b84df9af0de065697a86e2" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs2ce2dcfc19fb4919ac2b56fced851157" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsc47afe1448484fb4bf3de81c3d32e72f" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs976f82f3f0224cd39f1884f0e5f870c8" }, // Video added here
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs0ff4f9fec6a04176b960a6c04c58a6c3" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs01a274a035bf49c0b4a21dea3795b75e" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs7098503cd7924bdc81b85b7efb610311" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs2925c8a463c0447299c73d297b6fc618" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs6d3b99283cc94c7ba48b1af48ca71dd2" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsc4b1071c6f544769a28bc214b15741e5" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsc8cd87ca4c364397bb19c6dbb3e18db2" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs3e5375aaa6594f329bd13d28069d5fc0" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs3e6823aa833c492b8478e8320ccf5c64" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsc7eae6fd07d6420fa9f922077c644356" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs0b1673e00180446d90facb670853c0b6" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsc9802ee900ac4035b748dc372a1cd551" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsd1f0059f1e8746c49cc315a178742b0a" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evse831f05e4bf045959f22787f9d95d928" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsf14b9e5b5cef4ba9ba23a9b6271e98ca" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsf6aecfbb2457469e81ede28e307fd3e2" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs782e45f2036d482ea66502af0658a690" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs75595c9b233d4ad9854322e4e7926801" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs6366f4a345e34266ac3b9b54755d208a" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs39e883b7258c492981aeac0bb55e5e67" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs33b856e17bb9499f9ef48063c633d775" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs30a93664be4e4e37b9949ddfe08a0e33" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs30a0cd64f42140a8b45c98fd7e217def" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs16d28106f7ea48509d45a409764f91da" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs149d47fdedd24258ad17f1df9103ab99" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs572e0795a467476c9841fe6e82c7b7df" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs458aaadc4acf413db6bc129fd0ea72af" },
      

    ]
  },

  {
    "name": "Wave Curtains",
    "make": "Wave Curtains",
    "model": "",
    "type": "",
    "variety": "",
    "gallery": [
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs67ddae70df7f485093b9fab3cf9fa63c" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs3b42911b0d424e7e9ecd535d56075043" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs4cf348fe23ac444695777c97c65696ad" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs697d449513a3426580f790d465e35cc4" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs6f424b4efe1c4a618d10677473865958" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs08f8de58b255419c8af6ade3ede77e98" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs1315763fa8f6446da2be464c9003e8ea" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsb143fb87a2394560ba910af05b30adde" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evscabd2ae5631c409f8f54e4c93c4cddab" },

      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evs2a3b5a7b26204de7a0f1b3dab65b6428?toolbar=false&appearance=light&themecolor=green" },
      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evsb47d2b6028564c878e2a540054a50e1c?toolbar=false&appearance=light&themecolor=green" },
      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evseaf6ba9eefcf40acb2ef5913779cc19e?toolbar=false&appearance=light&themecolor=green" },
      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evs78d71c692d704eb088b283325da93c6c?toolbar=false&appearance=light&themecolor=green" },


    ]
  },

  {
    "name": "Pinch Pleat Curtains",
    "make": "Pinch  Pleat Curtains",
    "model": "",
    "type": "",
    "variety": "",
    "gallery": [
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs25cc0ffc645c421dac4e62eb3f5a1e8b" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsef7f47c510fc4dc0b76e3cacaee006c5" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs007a6e054dee4c73b2f52c593688710b" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs300a8fcbf2e048d1999eca741b7d5371" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs4c53e1224d21465d81a9cd1996563482" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs634cde19e0d542bfbc02fa24cb33cf4d" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsb085f42940f84b098907bb5e29e8e169" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsbf65f9fe709944aba3cef1b0722507ab" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs1246a93e56ea4a9bb63ac7ebf25722ef" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs12779959e9eb4a0e801b69790281f167" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs5ee958a56b62481dacf945d821df016c" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsd3710341b4a043848df1a75d211fb851" },
      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evs9d85d02bad4b4c3c9cc937538d9a1804?toolbar=false&appearance=light&themecolor=green" },


    ]
  },

  {
    "name": "Roman Blinds",
    "make": "Roman Blinds",
    "model": "",
    "type": "",
    "variety": "",
    "gallery": [
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs5a483ae98c8645c2a51bd647850625a8" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs135d9240f7f64c0dae5d72441bd5c0b0" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs1446cba753d84277a8a24a2a69dfc3b8" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs1a43ce45dd9d44c5b61c906ea3e8f4b5" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs7b1bab02edec4663914d69488f623b89" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs95b78622da734ec6ad1ab56b33392b4a" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsdc9bedc48828430f98f773ee06e8b26d" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsdcbc1d21998547eb93f00552118ebfab" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs5a0b936c46b74f7899c45cefd3696370" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsa5a1277bbe95440e9c2866f730a344bc" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsc20f3de4d0e0450ead0454f5d5749776" },
      { "type": "video", "src": " https://workdrive.zohopublic.eu/embed/h9evs217866c75d6f4347b61f936496351906?toolbar=false&appearance=light&themecolor=green" },
    ]
  },

  {
    "name": "Vision Blinds",
    "make": "Vision Blinds",
    "model": "",
    "type": "",
    "variety": "",
    "gallery": [
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsdc7f081c9a3740a2840261b0bbdb54fc" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs2e37c00bc17646029a9e147d7eb25525" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs73d8038fa853425ab0a593632177912c" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs81ced39e25364fba947c21aa2602c79c" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsb50ab2e4d3e84f33a4a6d413ed7dbe2b" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsc4ac5be8f703437689f4f94f6bfa2889" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsd54892dd028c4ee7aa42eba8b5c3671d" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs3d76c031582c4550ae7737d3c565841c" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs59dccb10d4fa4e259ddeecea8a587810" },
      { "type": "video", "src": " https://workdrive.zohopublic.eu/embed/h9evs1bb2f5312cc149a8a503bd897276b4c0?toolbar=false&appearance=light&themecolor=green" },
      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evs7f977ce241cf4efaa61549dff0ccfb7a?toolbar=false&appearance=light&themecolor=green " },
    ]

  },

  {
    "name": "Cafe style shutters",
    "make": "Cafe style shutters",
    "model": "",
    "type": "",
    "variety": "",
    "gallery": [
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs299ab64721ef4ba09f1a937571e51e72" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs2ec28b4015e849fea3d2598c292b2c8d" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs84804a3d83034d31bbbed76eedc0cef9" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs9434ac669dfb4871a273ccc23b313129" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evse08d2c97dfb5438ab3ee494a12b0b01d" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evse4e45060052546bf934c0f5da17b08ad" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evse0743629172b4b5da21120fba5417aee" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs9f03c6308c5d4f779cb666baaa2ab1f8" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs29ad04f9c7284e5584adc1fbc714d2c2" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs8c3aec61eeb14623aab931fceb360cb4" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsd2e3f065dbf94e8cb1fe5bc393a4a30f" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsead4a70c91cc42c7abafcdaf2d33684f" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs5b94b3ccba0c4402add7dc3d76c31aaa" },
      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evse0743629172b4b5da21120fba5417aee?toolbar=false&appearance=light&themecolor=green " },
    ]
  },

  {
    "name": "Nobel Blinds",
    "make": "Nobel Blinds",
    "model": "",
    "type": "",
    "variety": "",
    "gallery": [
      { "type": "image", "src": " https://previewengine-accl.zohoexternal.eu/image/WD/b3tiraece8463e6c4489dbeca5061e749bad4 " },
      // { "type": "image", "src": " https://previewengine-accl.zohoexternal.eu/image/WD/h9evs135d9240f7f64c0dae5d72441bd5c0b0 " },
      // { "type": "image", "src": " https://previewengine-accl.zohoexternal.eu/image/WD/h9evs1446cba753d84277a8a24a2a69dfc3b8" },
      // { "type": "image", "src": " https://previewengine-accl.zohoexternal.eu/image/WD/h9evs1a43ce45dd9d44c5b61c906ea3e8f4b5 " },
      // { "type": "image", "src": " https://previewengine-accl.zohoexternal.eu/image/WD/h9evsdc9bedc48828430f98f773ee06e8b26d " },
      // { "type": "image", "src": " https://previewengine-accl.zohoexternal.eu/image/WD/h9evsdcbc1d21998547eb93f00552118ebfab " },
      // { "type": "image", "src": " https://previewengine-accl.zohoexternal.eu/image/WD/h9evs5a0b936c46b74f7899c45cefd3696370 " },
      // { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs9f03c6308c5d4f779cb666baaa2ab1f8" },
      // { "type": "image", "src": " https://previewengine-accl.zohoexternal.eu/image/WD/h9evsa5a1277bbe95440e9c2866f730a344bc " },
      // { "type": "image", "src": " https://previewengine-accl.zohoexternal.eu/image/WD/h9evsc20f3de4d0e0450ead0454f5d5749776 " },
      // { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evs217866c75d6f4347b61f936496351906?toolbar=false&appearance=light&themecolor=green " },
    ]
  },

  {
    "name": "Vertical Blinds",
    "make": "Vertical Blinds",
    "model": "",
    "type": "",
    "variety": "",
    "gallery": [
      { "type": "image", "src": " https://previewengine-accl.zohoexternal.eu/image/WD/h9evs487c6dc6f007475084ff3e89e538137e " },
      { "type": "image", "src": " https://previewengine-accl.zohoexternal.eu/image/WD/h9evs9c61971c85604e43adf986ea189edbbd " },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsa19131185ae34a58bc29b493d740e4ea" },
      { "type": "image", "src": " https://previewengine-accl.zohoexternal.eu/image/WD/h9evse30ac794926242bbacab7d051dea2fbd " },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs5d64c86e0505498da3bce7f693902eff " },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs9371d59f44b747c99af85c01f105a068 " },
      { "type": "image", "src": " https://previewengine-accl.zohoexternal.eu/image/WD/h9evs42385640b0b7439fb7670c3570e433b8 " },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsb5fb28a998db44838cee2003fc5c3638" },
      { "type": "image", "src": " https://previewengine-accl.zohoexternal.eu/image/WD/h9evse00ded26d04b4f84b1635085abbae263 " },
      { "type": "image", "src": " https://previewengine-accl.zohoexternal.eu/image/WD/h9evs19c17b8a8a7c44448b1d05ea947bf23e " },
      { "type": "image", "src": " https://previewengine-accl.zohoexternal.eu/image/WD/h9evs239f77fa1e434d82823ba3f7df0a901e " },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs42829f8046fa4a049fc419778bd8eecc " },
      { "type": "image", "src": " https://previewengine-accl.zohoexternal.eu/image/WD/h9evs8cebd14d94294fd7aa1c185c4be9ce73 " },
      { "type": "image", "src": " https://previewengine-accl.zohoexternal.eu/image/WD/h9evs93ae50a944304e6aa5297dc8cc31ae39 " },
      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evsa5f771abb37a445188b85c99b1269da4?toolbar=false&appearance=light&themecolor=green " },
    ]
  },

  {
    "name": "Roller Blinds",
    "make": "Roller Blinds",
    "model": "",
    "type": "",
    "variety": "",
    "gallery": [
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs1868bb85f762439b9ae502b2ab058393" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs205382e1ea694015b35e1a96212ec13d" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs4455ec36fd16475daa6ed1202e4c3861" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsc0e329414a414d19909d776b171a940b" },
      // { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsb381261ca94f41b98d34aa7f431bafd8" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evse941c5c363d740c987e02928ac1c4cce" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs524c9c8fe8454246b04c4ce33587fbd4" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs735d525f6d344ab28fc676d71a65f69e" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsfbafd98cdfe140a4ad77bfdf6d4ef70d" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs4199f9dfa2f64ae18e4af5e38eb26039" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs5ab1f706d04740a6b3b16ead912be023" },
      // { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsd3710341b4a043848df1a75d211fb851" },
      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evs9674a3ad01e6419ea8f80f0f3dab84b7?toolbar=false&appearance=light&themecolor=green" },
      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evs1dfbe4b790614bb1b6a803ee993556b7?toolbar=false&appearance=light&themecolor=green" },
      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evsb381261ca94f41b98d34aa7f431bafd8?toolbar=false&appearance=light&themecolor=green" },
    ]
  },

  {
    "name": "Double Blinds",
    "make": "Double Blinds",
    "model": "",
    "type": "",
    "variety": "",
    "gallery": [
      { "type": "image", "src": " https://previewengine-accl.zohoexternal.eu/image/WD/h9evsa2da21fad8c74b21819f22482cb0a704 " },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evse31f1d3a61354c2a91a0a4efba1b2e79 " },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs896dabf81e7b4b23880b1fa9417a76ab" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs1b4276bfbee74295bb7e5afc1c647633 " },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs09c46554b04a4867b92684c08c5fa032 " },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs0e1f3571166b4d66bc02bbede42d6ef4 " },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs61d0086141bc460f9959de0387da9548 " },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsb6e72607c50441ec966be7f4d46bdec3" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsca53b68d96c24e67beac784117b98c00 " },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsf6f3445af80b4aebaf8876b2ad08b1a9 " },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs57247f33b31e42629d2c18bc6177207a " },
      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evsd0ec5debcb5f471782bb418094a2b416?toolbar=false&appearance=light&themecolor=green " },
      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evs7844351798bb485ca95eede592d76193?toolbar=false&appearance=light&themecolor=green" },
    ]
  },

  {
    "name": "Transparent Blinds",
    "make": "Transparent Blinds",
    "model": "",
    "type": "",
    "variety": "",
    "gallery": [
      { "type": "image", "src": " https://previewengine-accl.zohoexternal.eu/image/WD/h9evs7b6b4c7f7c634487a36b3e0f7dce8bac " },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs167ad2e48266413e887d28ba62101735 " },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs3f4b4c55164248d8b64d5ec840d381ca" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs7052dd480cdb4b8da2e39b64da4c2346 " },
      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evsa9b7c907263649209cd53c2f8dedab3f?toolbar=false&appearance=light&themecolor=green " },
    ]
  },


  {
    "name": "Twilights Blinds",
    "make": "Twilights Blinds",
    "model": "",
    "type": "",
    "variety": "",
    "gallery": [
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs0c8cfffd50f745a1ab517673dba3ae45 " },
      { "type": "image", "src": " https://previewengine-accl.zohoexternal.eu/image/WD/h9evs1fe8e1697c844c4ea1492beecf272101 " },
      { "type": "image", "src": " https://previewengine-accl.zohoexternal.eu/image/WD/h9evs95938cae4fba4dfca34ec8b00eadb59f " },
      { "type": "image", "src": " https://previewengine-accl.zohoexternal.eu/image/WD/h9evsefb8e360e13c48d3a7c19a25304e1f68 " },
    ]
  },

  {
    "name": "Pencil Pleate Curtain",
    "make": "Pencil Pleate Curtain",
    "model": "",
    "type": "",
    "variety": "",
    "gallery": [
      // { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs9d85d02bad4b4c3c9cc937538d9a1804 " },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs25cc0ffc645c421dac4e62eb3f5a1e8b " },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsef7f47c510fc4dc0b76e3cacaee006c5" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs007a6e054dee4c73b2f52c593688710b " },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs300a8fcbf2e048d1999eca741b7d5371 " },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs4c53e1224d21465d81a9cd1996563482 " },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs634cde19e0d542bfbc02fa24cb33cf4d " },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsb085f42940f84b098907bb5e29e8e169" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsbf65f9fe709944aba3cef1b0722507ab " },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs1246a93e56ea4a9bb63ac7ebf25722e " },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs12779959e9eb4a0e801b69790281f167 " },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs5ee958a56b62481dacf945d821df016c " },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsd3710341b4a043848df1a75d211fb851 " },



      // { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evsd0ec5debcb5f471782bb418094a2b416?toolbar=false&appearance=light&themecolor=green " },


      // { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evs7844351798bb485ca95eede592d76193?toolbar=false&appearance=light&themecolor=green" }
    ]
  },

  {
    "name": "Full Height Shutters",
    "make": "Full Height Shutters",
    "model": "",
    "type": "",
    "variety": "",
    "gallery": [
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsbf952a1af8b64e2aa4fcaf3863128279 " },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs96a628df8ed9410fbfa6ef997b9e26fc " },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs0667376c4de742fbbd19e0f80ab7ea33" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs28f7abcaf3c5478594241bf692ff4785" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs50ebc305e63e4cab9b4b56bee814dbe1 " },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsa17d7648b54f43f7852a6c46929b9446 " },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsa29236c073e441efa06e4b36fa6bc0ab " },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsaddf771d2f7f4298a03164a77bdd42c2" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs2d8a429d8c244918a2c064f536f79a4f " },




      // { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evsd0ec5debcb5f471782bb418094a2b416?toolbar=false&appearance=light&themecolor=green " },


      // { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evs7844351798bb485ca95eede592d76193?toolbar=false&appearance=light&themecolor=green" }
    ]
  },

  {
    "name": "Tier-On-Tier Shutters",
    "make": "Tier-On-Tier Shutters",
    "model": "",
    "type": "",
    "variety": "",
    "gallery": [
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs736ca349f2724dc9aebdeb1a262b1422 " },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs8bec76d1314741d6bc4b9a800a9078ab " },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsc5ccaa353dd54ddd986adb874a7bb3c8" },





      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evse013ad099b1a449ead1a498b0ead98d3?toolbar=false&appearance=light&themecolor=green" },


      // { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evs7844351798bb485ca95eede592d76193?toolbar=false&appearance=light&themecolor=green" }
    ]
  },

  {
    "name": "Outer Mount",
    "make": "",
    "model": "Outer Mount",
    "type": "",
    "variety": "",
    "gallery": [
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs251993cb305747678da4867948ced844" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs745632b9473442b0927673c8807f6c44" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsa14537f4f5ad46de8e29496d10f73ecb" },
    ]
  },
  {
    "name": "Recess Mount",
    "make": "",
    "model": "Recess Mount",
    "type": "",
    "variety": "",
    "gallery": [
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs1e84a297ef4343c19635cc4fdc6711a8" },
      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evs1697a03035ac427095a03b7a415d8291?toolbar=false&appearance=light&themecolor=green" },
      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evs8eff8c7e564d4b6cad8813abbfc61dd8?toolbar=false&appearance=light&themecolor=green" }
    ]
  },
  {
    "name": "Perfect Fit",
    "make": "",
    "model": "Perfect Fit",
    "type": "",
    "variety": "",
    "gallery": [
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs1f9e19e6a1fc435e9825391e429fbd58" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsb2b3a7895e564f8c891036c12060aa3b" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsd8f6f9f56796472ba5cfea6a42f21738" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsf77385ae0b304d328a16af3fcbde49ad" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs3b8f614b8dd0484e8c3761554f639328" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs9121488482934b01a323bfcf4c07d38b" },
    ]
  },

 

  {
    "name": "Sheer & Transparent",
    "make": "",
    "model": "",
    "type": "Sheer & Transparent",
    "variety": "",
    "gallery": [
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs28285c5253b64fc6bef01f2b8c05af88" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs0b60d3eee9024094930d4778a7d2de7f" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs46f16e226d954aeaa9ad94d55a6dbc35" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs5b3eed916f4c4258bca8c597201048c2" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs75c0ab1218a041d7867cd53e059483f1" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs7a9d61d81e3b4b20a7ea55abf0cfc309" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsa7c1dd51f592491d9ad86ab351c75a16" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsb85003edabd2462baf05d642840e438e" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsf105ecdf324f4fa8a4e49d1ff2db2eaa" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsb64fe7663a0f418287b15d5cfed54f0b" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs5a191e23a28c49c190890beaef7ada2c" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs8e3bdad426474674bb394be5f4a98330" },
      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evs7deaedf92ee4434ba1b2ace53eeb52d6?toolbar=false&appearance=light&themecolor=green" },
    ]
  },

  {
    "name": "Natural Light",
    "make": "",
    "model": "",
    "type": "Natural Light",
    "variety": "",
    "gallery": [
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs57a9e5f4565b461d8229dc8b7e057022" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsdb0ff7bf175f471888155c689246a488" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsa8aa2e74a1b94174ac934939ab6e4d69" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs60af515a37774214b5b6c9c695f39104" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsfb4a24ebfbb344aea62f931f00f40ef8" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs76cf479e46524a3c9ac87e44daa3c6d1" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs5e61abb4b0be4507b335a31c228b63ea" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs277fd62f8ee045b3b0f43d23c560e94c" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs5ec5c5a7fa2744348cabff4cf399966e" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsa183669d68c14fb285699c8ed00c1b27" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs5db1680c06cc43f59d4e5647cb5018fc" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs649d67ef34384cc7b1756b524d4d0a00" },
      
    ]
  },

  {
    "name": "Privacy & Light Control",
    "make": "",
    "model": "",
    "type": "Privacy & Light Control",
    "variety": "",
    "gallery": [
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs2ab321cedf6c4c0088a15af711300c68" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs4d09ac77afa845c78cfebd5d3d48934c" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs67fdc24a372745899eb24b7adf4449ae" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs6d4f06292819421c9e4dee0754ffe294" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs95e90eab6f2c42a09250f675f1806d60" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs9b9842e0fa3c45f9b5a7365c1648f8f9" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsc0cafbc0d86a41ecb1ff6671e7511c11" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evse4730a74f7a24112b32be3893060fd76" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsed8bd37e9b7648b6ad95323c2d88745e" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs771196cfb3e54b9e9d1d8c3034d9798b" },
      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evs0e0917e0d69e481e848a3d5d331f0fe7?toolbar=false&appearance=light&themecolor=green" },
      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evsfca3f50ba5614f8dbba48db54b01e7bd?toolbar=false&appearance=light&themecolor=green" },
      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evs7e72468f2a7547f992104aa32054767f?toolbar=false&appearance=light&themecolor=green" },
    ]
  },

  {
    "name": "Blackout",
    "make": "",
    "model": "",
    "type": "Blackout",
    "variety": "",
    "gallery": [
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs8be3b0dce6a0408fb58719a27d4c6261" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs8b30838bc23a43ccb245d4285b445d6c" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evscf06d3efc97d49a2bbabee24d8b1ce7d" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsc1545188e0364e1a9dcd2bb229804731" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs8c62537da9544d058ee867326b69bf8f" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs04b0eebabd034f5ebcd08e093068d851" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs7b35e45f23104192a18a59d132c5e0d7" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs76d7c7215eba4b82bcb571842a66e5a4" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs712815c284e64c5986052e5fdaff03bb" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs098ff32265984f239b2f398637e4a0c2" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs5bf89d74a68240e8b8f2dc1386d85b9f" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs0e046af698104ca7aa4ea112d5d70153" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs73db569e6c6e4af985d67f17f7d052a9" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evseae1e46a3ffd4816819ab71b936b2e2b" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs1a346918a06c4782805abbe9e54beded" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsc49fac33d4644110895cd8ef27c2670c" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs8ada081a01d140b0a0b00c0665f57c2b" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsaddb3106a7b14bb2b3c885b5e5be3b2a" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs99ed97f636fd4f9c928f245ad92ec310" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsa3d5e7bd37f84c81b0e9dfe8a6087aec" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs1f884cad4fd444408aaf34e695031d89" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs32964beca9724bd697fad5dfc9b37472" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evscdcc723513a64bfcbbe7aafdc6185b41" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evse14bd8d2b1fe43c0bed82acfd7f9ea18" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs7fee786743f6402786484af28a8ceaaf" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs604d37020aaf4d8d8148ad3a7ddb3a21" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsa2fac8404683499782e74f912b8667ea" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsb12ec75aa7a54f8292c7c3bff5b4e9e0" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs50e7281a035f40b29b5bb9eddb51bc08" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evse68f3c8f0a084d2aa7986b4671c9cedb" },
      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evs4d9493eca1b0422291f4f44d24393be8?toolbar=false&appearance=light&themecolor=green" },
      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evsef0db00fd1444ca19b44a93479cd8bca?toolbar=false&appearance=light&themecolor=green" },
      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evs4213dcc2da924d93a72d35953a0aeeb8?toolbar=false&appearance=light&themecolor=green" },
      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evsf31852ce962d44baad76d453f5353a2f?toolbar=false&appearance=light&themecolor=green" },
      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evs2dcac990565d498180f16c4ed0bafe44?toolbar=false&appearance=light&themecolor=green" },
      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evsb1b49177460547fba46c021791b401e1?toolbar=false&appearance=light&themecolor=green" },
    ]
  },
  {
    "name": "Maximum Blackout",
    "make": "",
    "model": "",
    "type": "Maximum Blackout",
    "variety": "",
    "gallery": [
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs2d4af113869345d4891d2e18b0954564" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs32a2ac5070ac44459722e95cd6b80c82" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evse4c053ea6ed64ee2a64349a9f59c3fb7" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs79e0aab64dbf498387f471d575cab85d" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsf89770aec61a48339908c7a2262a0259" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs4545b086b9d34468b5c8995f5b284fa4" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs730dc83ac3dd43b9b0b3d2fc73fa89e0" },
      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evs77a72b2c204b4afb863e321370ca5207?toolbar=false&appearance=light&themecolor=green" },
      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evs980ab1941c9e47eeb226ce8458314e44?toolbar=false&appearance=light&themecolor=green" },
    ]
  },





  {
    "name": "Regular Window",
    "make": "",
    "model": "",
    "type": "",
    "variety": "Regular Window",
    "gallery": [
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsde1a355c57a24a378bada5530c6c3ff8" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsc3f960538d8b477bad44949876770443" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs2379336fe4e84b789d1967f422dcb6ea" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evscdbdab9656d14c268c88373dfef34f91" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsd0ef6e898d7749b3a3308a72600e0e93" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs54e793b330d74172adde7d354fa22d6a" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs8f95100e9f934741988a89295d0d121b" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs35eb11f396c64dabb434d45f3b93f704" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs5e29909e697d418b8c67e3183b470c19" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs60af279609c3491c8ade0eaac498f04d" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs8e6bf39e1cf543f2b1e0e0e76fac4317" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs9b3f7f3712fd43b69ce078326d6817ea" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs9e823bc8b5b8404bb6119d3d3aa40d03" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsf8e80943bcd2437a97cffb6d21922de9 " },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs250f0bd02bb04f5ab4c43e258f126813 " },


      // { "type": "video", "src": "https://www.youtube.com/watch?v=5r9ySb1OE50" }
    ]



  },

  {
    "name": "Large Window",
    "make": "",
    "model": "",
    "type": "",
    "variety": "Large Window",
    "gallery": [
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs77a0565e97d545359fad8b10fb15f3c6" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsbb84a426d8b64eafb8bf4c41a8366259" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs7d02cc4393434be0bd704ffe40950431" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs4c60174575374d4e9f3ae49b624f3994" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs97835f8eaaf74153b5f7278a65d1dfc1" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsf5c24bde8f1a4136ba184ffbe1ec82e6" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs579d09cc42f24b8d97e7e1a3d5983035" },
      { "type": "image", "src": "ttps://previewengine-accl.zohoexternal.eu/image/WD/h9evs2abab561e71e4387af6a3a6f1ef334be" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs26dfe41e56724efa973f190252adea3c" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs57756917eaba491bbfae53d6540e1955" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs57168955d5e7496898819841fae1620f" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs7cbdb261d231413c89531e80b69c585b" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs212b0f6a3678494a961b04be68195dee" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs99213e78a77d4f19af211a67246c4105" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsc19226bb829b4b188f7e50a965d81379" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs8049aee9efa443ebbf92bcc6519a9cba" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs1069c4ea86784258ae5e4d37d70b40c6" },
    ]
  },


  {
    "name": "Angled Window",
    "make": "",
    "model": "",
    "type": "",
    "variety": "Angled Window",
    "gallery": [
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs94874986ac82441f8753ee08b0ae45bb" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsefe54f314d1e4ababe84bbba38131131" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs8c8330f684744af4893cb3b3149008fc" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs3c3468dae5ed460da9429662716c1de5" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs3e89720a97e0476fbf8aa8eb4c519db2" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs47f8c4c76a304cd1bcf739f0653a31b8" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs7187cd9f60634b1590f5bb05e8f52fdb" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs79336cde1cd045f6817f2b295ffb1fc2" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsb4e136c01a4e4be79aea3909eab2fc7b" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsf0246203bc5449c0b399d6b8932be508" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs00b13418fa7d4c11bde35847e6201bdf" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsd3925b25327540cb8a906f3ed8f5068b" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs8b933e1bf1e14511a4f19e0ed2711fd8" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs3a4871a34ea44ee2b03d529a57bf9576" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsb279fd97cad24b4284bb05baa423befb" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsa63fb1cd50a94de39ad88a012957d637" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs94acccc4773f45f38b2d4fe2903547ed" },
      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evs72f7f21084294d66932885835c04d857?toolbar=false&appearance=light&themecolor=green" },
    ]
  },

  {
    "name": "Loft Window",
    "make": "",
    "model": "",
    "type": "",
    "variety": "Loft Window",
    "gallery": [
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs44b2c3c5225e4fe89a812c3c4b5e09ef" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs32f9d6cbbbf54b0bb3cea94c0bed0d9c" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs37fac12c724c4f45b314ca124e48973d" },
      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evs9113376d91b049dc9b0e11dccd804f98?toolbar=false&appearance=light&themecolor=green" },
    ]
  },

  {
    "name": "Conservatory Window",
    "make": "",
    "model": "",
    "type": "",
    "variety": "Conservatory Window",
    "gallery": [
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs7755ec88fb144f9e95dfe252212b506e" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs809465e8d5a4444190494f3fc82fe855" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsa5a1c551ee8e4c5aab11f23e7401446a" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsdd9bf31e2e3a434487664a37740c0c1a" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsf0d4bd78cd4c4b1eb761b6a9fce16eec" },
    ]
  },

  {
    "name": "Sky Light Window",
    "make": "",
    "model": "",
    "type": "",
    "variety": "Sky Light Window",
    "gallery": [
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsde518070da08497082f8100216fa32f2" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs4c81135eb1b84b00baac279589ab170e" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs423a198a9e7749209b2457eb90a56ba4" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs76ec671a3bbd4de5afae32f71242ef81" },
      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evs87ad5c99071f4c07ad7f8760e0230a5b?toolbar=false&appearance=light&themecolor=green" },
      { "type": "video", "src": "https://workdrive.zohopublic.eu/embed/h9evsc1a3831f1bf44e25aefe17d4112b471c?toolbar=false&appearance=light&themecolor=green" },
    ]
  },

  {
    "name": "Bay Window",
    "make": "",
    "model": "",
    "type": "",
    "variety": "Bay Window",
    "gallery": [
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsdc7f081c9a3740a2840261b0bbdb54fc" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs2e37c00bc17646029a9e147d7eb25525" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs73d8038fa853425ab0a593632177912c" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs81ced39e25364fba947c21aa2602c79c" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsb50ab2e4d3e84f33a4a6d413ed7dbe2b" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsc4ac5be8f703437689f4f94f6bfa2889" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evsd54892dd028c4ee7aa42eba8b5c3671d" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs3d76c031582c4550ae7737d3c565841c" },
      { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs59dccb10d4fa4e259ddeecea8a587810" },
      { "type": "video", "src": " workdrive.zohopublic.eu/embed/h9evs1bb2f5312cc149a8a503bd897276b4c0?toolbar=false&appearance=light&themecolor=green" },
      { "type": "video", "src": "workdrive.zohopublic.eu/embed/h9evs7f977ce241cf4efaa61549dff0ccfb7a?toolbar=false&appearance=light&themecolor=green " },
    ]
  }


  // {
  //   "name": "Large Window",
  //   "make": "",
  //   "model": "",
  //   "type": "",
  //   "variety": "Large Window",
  //   "gallery": [
  //     { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs3b999d5ed63e42f0b6a72cca594cb045" },
  //     { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs5d9fc729bd934d9b8f2e7c9349d76697" },
  //     { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs619d600e052f48c4b0124abe48230669" },
  //     { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evs975b5a82ac7749d4ad2277222e79c107" },
  //     { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evscb1ab513c7e4406fa0fdb974caee60e1" },
  //     { "type": "image", "src": "https://previewengine-accl.zohoexternal.eu/image/WD/h9evse5ecc7d511604f1cb2d7029f47bf20f5" },
  //     { "type": "image", "src": "https://workdrive.zohopublic.eu/embed/h9evs49d0ce9c07234f75b4a64e399020f38c?toolbar=false&appearance=light&themecolor=green" },
  //     { "type": "image", "src": "https://workdrive.zohopublic.eu/embed/h9evs548aa58896d84f49b97466b7e9a04911?toolbar=false&appearance=light&themecolor=green" },
  //   ]
  // },






];
